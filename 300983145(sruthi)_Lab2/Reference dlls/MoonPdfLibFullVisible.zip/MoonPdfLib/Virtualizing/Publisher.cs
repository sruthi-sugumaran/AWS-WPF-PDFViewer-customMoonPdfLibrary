﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace MoonPdfLib.Virtualizing
{
    class Publisher
    {
        public string PublisherName = "seekyourcareer.in";
        public delegate void EventHandler(Publisher P, BroadCast e);
        public event EventHandler EventTicked;
        //create a function to check if event is fired, and handle that event with the help of event handler
        public void NewPost()
        {
            while (true)
            {

                Thread.Sleep(3000); // fire event after every 3 second
                if (EventTicked != null)
                {
                    BroadCast bc = new BroadCast();
                    bc.BroadCast_Date = DateTime.Now;
                    bc.BroadCast_Message = "New Article has been Published!!!";
                    EventTicked(this, bc);
                }
            }
        }
    }
    class BroadCast // class containing data which is broadcasted by the publisher
    {
        private DateTime broadCast_Date;
        public DateTime BroadCast_Date
        {
            get { return broadCast_Date; }
            set { broadCast_Date = value; }
        }

        private string broadCast_Message;
        public string BroadCast_Message
        {
            get { return broadCast_Message; }
            set { broadCast_Message = value; }
        }
    }
}
