﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace MoonPdfLib.Virtualizing
{
    public class SingletonPublisherClass
    {
        SingletonPublisherClass()
        {
        }

        private static readonly object padlock = new object();
        private static SingletonPublisherClass instance = null;

        public static SingletonPublisherClass Instance
        {
            get
            {
                lock (padlock)
                {
                    if (instance == null)
                    {
                        instance = new SingletonPublisherClass();
                    }
                    return instance;
                }
            }
        }

        public delegate void EventHandler(SingletonPublisherClass P, BroadCast e);
        public event EventHandler EventTicked;

        public void NewPost(int pagenumber)
        {
            /* while (true)
             {
                 Thread.Sleep(3000); // fire event after every 3 second
                 if (EventTicked != null)
                 */

            BroadCast bc = new BroadCast();
            bc.BroadCast_Date = DateTime.Now;
            bc.Page_Number = pagenumber;
            EventTicked(this, bc);

        }
    }


    public class BroadCast // class containing data which is broadcasted by the publisher
    {
        private DateTime broadCast_Date;
        public DateTime BroadCast_Date
        {
            get { return broadCast_Date; }
            set { broadCast_Date = value; }
        }

        private int pageNumber;
        public int Page_Number
        {
            get { return pageNumber; }
            set { pageNumber = value; }
        }
    }
}
